microbit_CAR.setPixelRGB(microbit_CAR.Lights.All, RGBColors.Off)
microbit_CAR.showLight()
basic.forever(function () {
	
})
